package com.hmw.ser;

import org.springframework.stereotype.Service;

@Service
public class MapServiceImp implements IMapService {

	@Override
	public String getMgs() {
		// TODO Auto-generated method stub
		return "Hello~";
	}

}
