package com.hmw.ser;
 

 
public interface IMapService { 
	
	public String getMgs();

}
