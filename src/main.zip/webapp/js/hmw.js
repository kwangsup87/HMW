/*
 * HMW JavaScript Library 
 * 
 * Released under the MIT license
 */

(function(){
	
})();